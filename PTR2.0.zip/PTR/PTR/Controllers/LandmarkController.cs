﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PTR.Data;
using PTR.Models;

namespace PTR.Controllers
{
    [Authorize]
    public class LandmarkController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _context;
        public LandmarkController(UserManager<ApplicationUser> userManager, ApplicationDbContext context)
        {
            _userManager = userManager;
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var currentUser = await _userManager.GetUserAsync(User);
            var idCurrentUser = currentUser.Id;

            var adminUser = await _userManager.FindByEmailAsync("test.ptrapp@gmail.com");
            var idAdminUser = adminUser.Id;


            var lnd = _context.Landmark.Where(l => l.userID == idCurrentUser);
            var ls = lnd.ToList();

            if (idCurrentUser != idAdminUser)
            {
                if (ls.Count == 0)
                {
                    var landmarks = _context.Landmark.ToList();
                    var landmarksCount = landmarks.Count;

                    var landmarks1 = _context.Landmark.Where(la => la.userID == idAdminUser).ToList();
                    var landmarks1Count = landmarks1.Count;

                    var copyLandmarks = landmarks;

                    List<Landmark> final = new List<Landmark>();
                    var finalCount = landmarksCount + landmarks1Count;
                    for (var i = 0; i < landmarksCount; i++)
                    {
                        final[i] = landmarks[i];
                    }

                    var z = 0;
                    for (var j = landmarksCount; j < finalCount; j++)
                    {
                       // landmarks1[z].ID = j;
                        final[j] = landmarks1[z];
                        z++;
                    }


                    for (var i = 0; i < finalCount; i++)
                        _context.Landmark.Add(landmarks1[i]);
                     _context.SaveChanges();

                    //var landmarks = _context.Landmark.Where(la => la.userID == idAdminUser).ToList();
                    //var l = landmarks;
                    //var lCount = l.Count;
                    //var allLandCount = lCount*2;
                    //List<Landmark> allLand = new List<Landmark>();
                    //for (var i = 0; i < allLandCount; i++)
                    //{
                    //    allLand[i] = l[i];

                    //}
                    //allLand[allLandCount] = allLand[allLandCount - 1];
                    //allLand[allLandCount].ID = allLandCount;

                    //for (int i = 0; i < l.Count; i++)
                    //{
                    //    if (l[i].userID == idAdminUser)
                    //    {
                    //        l[i].ID = l[i].ID + idCurrentUser;
                    //        l[i].userID = idCurrentUser;
                    //    }
                    //}

                    //foreach (Landmark landm in l)
                    //{
                    //    _context.Landmark.Add(landm);
                    //    _context.SaveChanges();

                    //}

                    return View(final);
                }
                else
                {

                    return View(ls);
                }
            }
            else
            {
                return View(_context.Landmark.ToList());
            }

        }




        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Landmark landmark = _context.Landmark.SingleOrDefault(x => x.ID == id);



            if (landmark == null)
            {
                return NotFound();
            }
            return View(landmark);

        }

        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Name,Category,Description,categoryID, Rating")] Landmark landmark)
        {
            if (ModelState.IsValid)
            {
                landmark.Rating = 5;
                var user = await _userManager.GetUserAsync(User);
                landmark.userID = user.Id;

                _context.Add(landmark);

               await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(landmark);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var landmark = await _context.Landmark.SingleOrDefaultAsync(m => m.ID == id);
            if (landmark == null)
            {
                return NotFound();
            }
            return View(landmark);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, [Bind("ID,Name,Category,Description,categoryID,Rating")] Landmark landmark)
        {
            if (id==null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var user = await _userManager.GetUserAsync(User);
                    landmark.userID = user.Id;
                    _context.Update(landmark);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LandmarkExists(landmark.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(landmark);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var landmark = await _context.Landmark
                .SingleOrDefaultAsync(m => m.ID == id);
            var user = await _userManager.GetUserAsync(User);
            landmark.userID = user.Id;
            if (landmark == null)
            {
                return NotFound();
            }

            return View(landmark);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var landmark = await _context.Landmark.SingleOrDefaultAsync(m => m.ID == id);
            _context.Landmark.Remove(landmark);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LandmarkExists(int id)
        {
            return _context.Landmark.Any(e => e.ID == id);
        }




        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (returnUrl != null)
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }


        public async Task<IActionResult> VisitedAsync(int? id)
        {
            if (id ==null)
            {
                return NotFound();
            }
            var user = await _userManager.GetUserAsync(User);
            var currentUserId = user.Id;

            Landmark landmark = _context.Landmark.SingleOrDefault(x => x.ID == id);



            if (landmark == null)
            {
                return NotFound();
            }

            return View(landmark);
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> VisitedAsync(int id, [Bind("ID,Name,Category,Description,categoryID, Rating, userEmail")] Landmark landmark, Landmark lnd)
        {
            if (id != landmark.ID)
            {
                return NotFound();
            }



            if (ModelState.IsValid)
            {
                try
                {
                    lnd = landmark;

                    var user = await _userManager.GetUserAsync(User);
                    lnd.userID = user.Id;



                    _context.Attach(lnd);
                    _context.Entry(lnd).Property("Rating").IsModified = true;

                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LandmarkExists(landmark.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(lnd);
        }


        public IActionResult FunSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/1";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult IndoorSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/2";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult OutdoorSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/3";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult ArchitectureDesignSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/4";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult BoutiquesSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/5";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult CultureHistorySort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/6";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult FartherAwaySort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/7";
            return RedirectToLocal(returnUrl);
        }
        public IActionResult ParksGardensSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/8";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult ReligiousSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/9";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult TopLandmarkSort()
        {
            var land = _context.Landmark.OrderBy(m => m.Name).OrderByDescending(m => m.Rating).ToList();

            if (land == null)
            {
                return NotFound();
            }
            return View(land);

        }


        public IActionResult AZSort()
        {
            var land = _context.Landmark.OrderByDescending(m => m.Rating).OrderBy(m => m.Name).ToList();

            if (land == null)
            {
                return NotFound();
            }
            return View(land);

        }

    }
}