﻿using PTR.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PTR.Data
{
    public class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            context.Database.EnsureCreated();

            if (context.Landmark.Any())
            {
                return;
            }


            if (context.Category.Any())
            {
                return;
            }

            if (context.Rating.Any())
            {
                return;
            }

            var categories = new Category[]
            {
                new Category{Name="Fun", minAge=0, maxAge=105 },
                new Category{Name="Indoor", minAge=0, maxAge=105},
                new Category{Name="Outdoor", minAge=14, maxAge=105},
                new Category{Name="Architecture&Design", minAge=0, maxAge=105, properAge=45},
                new Category{Name="Boutiques", minAge=18, maxAge=105, properAge =30},
                new Category{Name="Culture&History", minAge=14, maxAge=105, properAge =45},
                new Category{Name="Farther Away", minAge=0, maxAge=105, properAge =20},
                new Category{Name="Parks&Gardens", minAge=0, maxAge=105, properAge =25},
                new Category{Name="Religious", minAge=0, maxAge=105, properAge =45}


            };


            foreach (Category category in categories)
            {
                context.Category.Add(category);
            }

            context.SaveChanges();

            var ratings = new Rating[]
            {
                new Rating{ ratingName="Rating 1", ratingCategory="very weak"},
                new Rating{ ratingName="Rating 2", ratingCategory="very weak"},
                new Rating{ ratingName="Rating 3", ratingCategory="weak"},
                new Rating{ ratingName="Rating 4", ratingCategory="weak"},
                new Rating{ ratingName="Rating 5", ratingCategory="medium"},
                new Rating{ ratingName="Rating 6", ratingCategory="medium"},
                new Rating{ ratingName="Rating 7", ratingCategory="strong"},
                new Rating{ ratingName="Rating 8", ratingCategory="strong"},
                new Rating{ ratingName="Rating 9", ratingCategory="very strong"},
                new Rating{ ratingName="Rating 10", ratingCategory="very strong"}

            };


            foreach (Rating rating in ratings)
            {
                context.Rating.Add(rating);
            }

            context.SaveChanges();

        }
    }
}
