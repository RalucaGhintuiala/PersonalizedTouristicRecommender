﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PTR.Data;
using PTR.Models;

namespace PTR.Controllers
{
    [Authorize]
    public class RatingController : Controller
    {

        private readonly ApplicationDbContext _context;
        public RatingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.Rating.ToList());
        }

        public async Task<IActionResult> YouMayBeInterested()
        {


            var rating7 = await _context.Rating
                     .Include(rat => rat.Landmarks)
                     .SingleOrDefaultAsync(rat => rat.ratingID == 7);

            var rating8 = await _context.Rating
                    .Include(rat => rat.Landmarks)
                    .SingleOrDefaultAsync(rat => rat.ratingID == 8);

            var rating9 = await _context.Rating
                   .Include(rat => rat.Landmarks)
                   .SingleOrDefaultAsync(rat => rat.ratingID == 9);

            var rating10 = await _context.Rating
                    .Include(rat => rat.Landmarks)
                    .SingleOrDefaultAsync(rat => rat.ratingID == 10);

            if (rating7 == null || rating8 == null || rating9 == null || rating10 == null)
            {
                return NotFound();
            }
            else
            {
                var landmarks7 = _context.Landmark.Where(l => l.Rating == rating7.ratingID);
                List<Landmark> lista7 = new List<Landmark>();
                lista7 = landmarks7.ToList();

                var landmarks8 = _context.Landmark.Where(l => l.Rating == rating8.ratingID);
                List<Landmark> lista8 = new List<Landmark>();
                lista8 = landmarks8.ToList();

                var landmarks9 = _context.Landmark.Where(l => l.Rating == rating9.ratingID);
                List<Landmark> lista9 = new List<Landmark>();
                lista9 = landmarks9.ToList();

                var landmarks10 = _context.Landmark.Where(l => l.Rating == rating10.ratingID);
                List<Landmark> lista10 = new List<Landmark>();
                lista10 = landmarks10.ToList();

                var union = lista7.Union(lista8).Union(lista9).Union(lista10).ToList();
                union = union.OrderBy(m => m.categoryID).ToList();

                return View(union);
            }



        }


    }
}