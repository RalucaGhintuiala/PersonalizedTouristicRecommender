﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PTR.Data;
using PTR.Models;

namespace PTR.Controllers
{
    [Authorize]
    public class LandmarkController : Controller
    {
        private readonly ApplicationDbContext _context;
        public LandmarkController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View(_context.Landmark.ToList());
        }



        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Landmark landmark = _context.Landmark.SingleOrDefault(x => x.ID == id);



            if (landmark == null)
            {
                return NotFound();
            }
            return View(landmark);

        }

        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Name,Category,Description,categoryID,Rating")] Landmark landmark)
        {
            if (ModelState.IsValid)
            {
                _context.Add(landmark);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(landmark);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var landmark = await _context.Landmark.SingleOrDefaultAsync(m => m.ID == id);
            if (landmark == null)
            {
                return NotFound();
            }
            return View(landmark);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Name,Category,Description,Rating")] Landmark landmark)
        {
            if (id != landmark.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(landmark);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LandmarkExists(landmark.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(landmark);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var landmark = await _context.Landmark
                .SingleOrDefaultAsync(m => m.ID == id);
            if (landmark == null)
            {
                return NotFound();
            }

            return View(landmark);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var landmark = await _context.Landmark.SingleOrDefaultAsync(m => m.ID == id);
            _context.Landmark.Remove(landmark);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LandmarkExists(int id)
        {
            return _context.Landmark.Any(e => e.ID == id);
        }


        public IActionResult Visited(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Landmark landmark = _context.Landmark.SingleOrDefault(x => x.ID == id);
            if (landmark == null)
            {
                return NotFound();
            }

            return View();
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (returnUrl != null)
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public IActionResult FunSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/1";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult IndoorSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/2";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult OutdoorSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/3";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult ArchitectureDesignSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/4";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult BoutiquesSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/5";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult CultureHistorySort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/6";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult FartherAwaySort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/7";
            return RedirectToLocal(returnUrl);
        }
        public IActionResult ParksGardensSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/8";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult ReligiousSort()
        {
            var returnUrl = "https://localhost:44319/Category/LandSort/9";
            return RedirectToLocal(returnUrl);
        }

        public IActionResult TopLandmarkSort()
        {
            var land = _context.Landmark.OrderBy(m => m.Name).OrderByDescending(m => m.Rating).ToList();

            if (land == null)
            {
                return NotFound();
            }
            return View(land);

        }


        public IActionResult AZSort()
        {
            var land = _context.Landmark.OrderByDescending(m => m.Rating).OrderBy(m => m.Name).ToList();

            if (land == null)
            {
                return NotFound();
            }
            return View(land);

        }

    }
}