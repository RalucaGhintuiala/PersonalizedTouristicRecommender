﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PTR.Data;
using PTR.Models;

namespace PTR.Controllers
{
    [Authorize]
    public class RatingController : Controller
    {

        private readonly ApplicationDbContext _context;
        public RatingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.Rating.ToList());
        }

        public async Task<IActionResult> YouMayBeInterested()
        {


            var rating7 = await _context.Rating
                     .Include(rat => rat.Landmarks)
                     .SingleOrDefaultAsync(rat => rat.ratingID == 7);

            var rating8 = await _context.Rating
                    .Include(rat => rat.Landmarks)
                    .SingleOrDefaultAsync(rat => rat.ratingID == 8);

            var rating9 = await _context.Rating
                   .Include(rat => rat.Landmarks)
                   .SingleOrDefaultAsync(rat => rat.ratingID == 9);

            var rating10 = await _context.Rating
                    .Include(rat => rat.Landmarks)
                    .SingleOrDefaultAsync(rat => rat.ratingID == 10);

            if (rating7 == null || rating8 == null || rating9 == null || rating10 == null)
            {
                return NotFound();
            }
            else
            {
                var landmarks7 = _context.Landmark.Where(l => l.Rating == rating7.ratingID);
                List<Landmark> lista7 = new List<Landmark>();
                lista7 = landmarks7.ToList();

                var landmarks8 = _context.Landmark.Where(l => l.Rating == rating8.ratingID);
                List<Landmark> lista8 = new List<Landmark>();
                lista8 = landmarks8.ToList();

                var landmarks9 = _context.Landmark.Where(l => l.Rating == rating9.ratingID);
                List<Landmark> lista9 = new List<Landmark>();
                lista9 = landmarks9.ToList();

                var landmarks10 = _context.Landmark.Where(l => l.Rating == rating10.ratingID);
                List<Landmark> lista10 = new List<Landmark>();
                lista10 = landmarks10.ToList();

                var union = lista7.Union(lista8).Union(lista9).Union(lista10).ToList();
                union = union.OrderBy(m => m.categoryID).ToList();

                int[] frecv = new int[10];
                frecv[0] = 0;
                for (var i = 1; i < 10; i++)
                    frecv[i] = 0;
                foreach (Landmark l in union)
                {
                    if (l.categoryID == 1)
                    {
                        frecv[1]++;
                    }
                    if (l.categoryID == 2)
                    {
                        frecv[2]++;
                    }
                    if (l.categoryID == 3)
                    {
                        frecv[3]++;
                    }
                    if (l.categoryID == 4)
                    {
                        frecv[4]++;
                    }
                    if (l.categoryID == 5)
                    {
                        frecv[5]++;
                    }
                    if (l.categoryID == 6)
                    {
                        frecv[6]++;
                    }
                    if (l.categoryID == 7)
                    {
                        frecv[7]++;
                    }
                    if (l.categoryID == 8)
                    {
                        frecv[8]++;
                    }
                    if (l.categoryID == 9)
                    {
                        frecv[9]++;
                    }

                }


                List<Landmark> union2 = new List<Landmark>();

                if (frecv[1] > 2)
                {
                    var cat1 = await _context.Category
                                        .Include(rat => rat.Landmarks)
                                        .SingleOrDefaultAsync(cat => cat.ID == 1);
                    var lndCat1 = _context.Landmark.Where(l => l.categoryID == cat1.ID).ToList();
                    List<Landmark> lndCat1R7 = new List<Landmark>();
                    foreach (Landmark l in lndCat1)
                    {
                        if (l.Rating == 7)
                            lndCat1R7.Add(l);

                    }
                    var l1 = lndCat1R7.ToList();

                    union2.AddRange(l1);
                }
                if (frecv[2] > 2)
                {
                    var cat2 = await _context.Category
                                      .Include(rat => rat.Landmarks)
                                      .SingleOrDefaultAsync(cat => cat.ID == 2);
                    var lndCat2 = _context.Landmark.Where(l => l.categoryID == cat2.ID).ToList();
                    var l2 = lndCat2.ToList();

                    union2.AddRange(l2);
                }
                if (frecv[3] > 2)
                {
                    var cat3 = await _context.Category
                                      .Include(rat => rat.Landmarks)
                                      .SingleOrDefaultAsync(cat => cat.ID == 3);
                    var lndCat3 = _context.Landmark.Where(l => l.categoryID == cat3.ID).ToList();
                    var l3 = lndCat3.ToList();

                    union2.AddRange(l3);
                }
                if (frecv[4] > 2)
                {
                    var cat4 = await _context.Category
                                      .Include(rat => rat.Landmarks)
                                      .SingleOrDefaultAsync(cat => cat.ID == 4);
                    var lndCat4 = _context.Landmark.Where(l => l.categoryID == cat4.ID).ToList();
                    var l4 = lndCat4.ToList();

                    union2.AddRange(l4);
                }
                if (frecv[5] > 2)
                {
                    var cat5 = await _context.Category
                                      .Include(rat => rat.Landmarks)
                                      .SingleOrDefaultAsync(cat => cat.ID == 5);
                    var lndCat5 = _context.Landmark.Where(l => l.categoryID == cat5.ID).ToList();
                   
                    List<Landmark> lndCat5R7 = new List<Landmark>();
                    foreach (Landmark l in lndCat5)
                    {
                        if (l.Rating == 7)
                            lndCat5R7.Add(l);

                    }
                    var l5 = lndCat5R7.ToList();


                    union2.AddRange(l5);
                }
                if (frecv[6] > 2)
                {
                    var cat6 = await _context.Category
                                      .Include(rat => rat.Landmarks)
                                      .SingleOrDefaultAsync(cat => cat.ID == 6);
                    var lndCat6 = _context.Landmark.Where(l => l.categoryID == cat6.ID).ToList();
                    var l6 = lndCat6.ToList();

                    union2.AddRange(l6);
                }
                if (frecv[7] > 2)
                {
                    var cat7 = await _context.Category
                                      .Include(rat => rat.Landmarks)
                                      .SingleOrDefaultAsync(cat => cat.ID == 7);
                    var lndCat7 = _context.Landmark.Where(l => l.categoryID == cat7.ID).ToList();
                    var l7 = lndCat7.ToList();

                    union2.AddRange(l7);
                }
                if (frecv[8] > 2)
                {
                    var cat8 = await _context.Category
                                      .Include(rat => rat.Landmarks)
                                      .SingleOrDefaultAsync(cat => cat.ID == 8);
                    var lndCat8 = _context.Landmark.Where(l => l.categoryID == cat8.ID).ToList();
                    var l8 = lndCat8.ToList();

                    union2.AddRange(l8);
                }
                if (frecv[9] > 2)
                {
                    var cat9 = await _context.Category
                                      .Include(rat => rat.Landmarks)
                                      .SingleOrDefaultAsync(cat => cat.ID == 9);
                    var lndCat9 = _context.Landmark.Where(l => l.categoryID == cat9.ID).ToList();
                    var l9 = lndCat9.ToList();

                    union2.AddRange(l9);
                }
                var finalUnion = union2.ToList();
                return View(finalUnion);
            }


        }

    }

}


