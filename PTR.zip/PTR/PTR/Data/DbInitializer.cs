﻿using PTR.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PTR.Data
{
    public class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            context.Database.EnsureCreated();

            if (context.Landmark.Any())
            {
                return;
            }

            var landmarks = new Landmark[]
            {
                //new Landmark{ Name="Jewish Museum", Category="Museum", Description="The Jewish Museum in Bucharest, Romania is located in the former Templul Unirea Sfântă synagogue, which survived both World War II and Nicolae Ceauşescu unscathed.", Rating=10 /*, Subscribed=true*/},
                //new Landmark{ Name="Yeshua Tova Synagogue", Category="Religious place", Description="The Yeshua Tova Synagogue in Bucharest, Romania, is the city's oldest synagogue, serving the local Jewish community. The synagogue is located on 9, Take Ionescu Street, near Piaţa Amzei. It was built in 1827, and renovated in 2007.", Rating=10 /*, Subscribed=true*/},
                //new Landmark{ Name="Great Synagogue", Category="Religious place", Description="The Great Synagogue, originally known as the Polish Synagogue, was built between 1845-1846 in Bucharest by the Ashkenazi Jewish community from Poland and is the first great worship building of this community.", Rating=10/* , Subscribed=true*/},
                //new Landmark{ Name="Choral Temple", Category="Religious place", Description="The Choral Temple is a synagogue located in Bucharest, Romania. It is a copy of Vienna's Leopoldstadt-Tempelgasse Great Synagogue, which was raised in 1855-1858. It was designed by Enderle and Freiwald and built between 1857 - 1867.", Rating=10/* , Subscribed=true*/},
                //new Landmark{ Name="Biserica Alba", Category="Church", Description="Located on Mogoşoaia Bridge, on the longest and at the same time the most elegant street in Bucharest, where the wealthiest boyars and most consuls lived, where were the most elegant shops and shops and where you needed an hour to go crossing from one end to the other, the White Church was for three centuries, a spiritual and cultural indisputable landmark for all the faithful who have crossed the threshold.", Rating=10 /*, Subscribed=true*/}

            };

            foreach (Landmark land in landmarks)
            {
                context.Landmark.Add(land);
            }


            if (context.Category.Any())
            {
                return;
            }

            var categories = new Category[]
            {
                new Category{Name="Fun", minAge=0, maxAge=105 },
                new Category{Name="Indoor", minAge=0, maxAge=105},
                new Category{Name="Outdoor", minAge=14, maxAge=105},
                new Category{Name="Architecture&Design", minAge=0, maxAge=105, properAge=45},
                new Category{Name="Boutiques", minAge=18, maxAge=105, properAge =30},
                new Category{Name="Culture&History", minAge=14, maxAge=105, properAge =45},
                new Category{Name="Farther Away", minAge=0, maxAge=105, properAge =20},
                new Category{Name="Parks&Gardens", minAge=0, maxAge=105, properAge =25},
                new Category{Name="Religious", minAge=0, maxAge=105, properAge =45}
                               
                //new Category{Name="Club", minAge=18, maxAge=105, properAge =25}
                //new Category{Name="Art Gallery", minAge=0, maxAge=105, properAge =45},
                //new Category{Name="Botanical Garden", minAge=0, maxAge=105, properAge =25},
                //new Category{Name="Zoo", minAge=0, maxAge=105, properAge =25},
                //new Category{Name="Lake", minAge=0, maxAge=105, properAge =25},
                //new Category{Name="Shop", minAge=0, maxAge=105, properAge =35},
                //new Category{Name="Monument", minAge=0, maxAge=105, properAge =35},
                //new Category{Name="Forest", minAge=0, maxAge=105, properAge =30},
                //new Category{Name="Park", minAge=0, maxAge=105, properAge =25},
                //new Category{Name="Water Park", minAge=0, maxAge=105, properAge =25},
                //new Category{Name="Historic Landmark", minAge=0, maxAge=105, properAge =45},
                //new Category{Name="Theatre", minAge=0, maxAge=105, properAge =40},
                //new Category{Name="Circus", minAge=0, maxAge=105, properAge =25}
            };

            foreach (Landmark land in landmarks)
            {
                context.Landmark.Add(land);
            }

            foreach (Category category in categories)
            {
                context.Category.Add(category);
            }

            context.SaveChanges();


        }
    }
}
