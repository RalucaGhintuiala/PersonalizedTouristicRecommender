﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PTR.Data;
using PTR.Models;


namespace PTR.Controllers
{
    [Authorize]
    public class CategoryController : Controller
    {
        private readonly ApplicationDbContext _context;
        public CategoryController(ApplicationDbContext context)
        {
            _context = context;
        }
        [Authorize(Roles = "Admin")]
        public IActionResult Index()
        {
            return View(_context.Category.ToList());
        }


        //public async Task<IActionResult> Index()
        //{
        //    return View(await _context.Category.ToListAsync());
        //}




        //private bool LandmarkExists(int id)
        //{
        //    return _context.Landmark.Any(e => e.ID == id);
        //}

        [Authorize(Roles = "Admin,Member")]
        public async Task<IActionResult> LandSort(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var category = await _context.Category
                   .Include(cat => cat.Landmarks)
                   .SingleOrDefaultAsync(cat => cat.ID == id);
            if (category == null)
            {
                return NotFound();
            }
            return View(category);
        }


        [Authorize(Roles = "Admin,Member")]
        public async Task<IActionResult> LandRatingSort(int? id)
        {

            if (id == null)
            {

            }

            var category = await _context.Category
                     .Include(cat => cat.Landmarks)
                     .SingleOrDefaultAsync(cat => cat.ID == id);

            if (category == null)
            {
                return NotFound();
            }
            else
            {
                var list = _context.Landmark.Where(l => l.categoryID == category.ID);
                var lst = list.OrderByDescending(m => m.Rating).ToList();
                return View(lst);
            }



        }

        [Authorize(Roles = "Admin,Member")]
        public async Task<IActionResult> YouMayBeInterested(int? id)
        {

            if (id == null)
            {

            }

            var category = await _context.Category
                     .Include(cat => cat.Landmarks)
                     .SingleOrDefaultAsync(cat => cat.ID == id);

            if (category == null)
            {
                return NotFound();
            }
            else
            {
                var list = _context.Landmark.Where(l => l.categoryID == category.ID);
                var lst = list.OrderByDescending(m => m.Rating).ToList();

                var fiveList = new List<Landmark>();
                for (int i = 0; i < lst.Count; i++)
                {
                    if (lst.Count > 5)
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            if (lst[j] != null)
                                fiveList.Add(lst[j]);

                        }
                        break;
                    }
                    else
                    {
                        for (int z = 0; z < 5; z++)
                        {
                            if (lst[z] != null)
                                fiveList.Add(lst[z]);
                        }
                    }
                }

                return View(fiveList);
            }



        }


    }
}