﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PTR.Models
{
    public class RecommenderContext : DbContext
    {
        public RecommenderContext(DbContextOptions<RecommenderContext> options)
            : base(options)
        {
        }


       
    }
}
