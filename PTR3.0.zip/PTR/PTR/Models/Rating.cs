﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PTR.Models
{
    public class Rating
    {
        public int ratingID { get; set; }
        public string ratingName { get; set; }
        public string ratingCategory { get; set; }

        public List<Landmark> Landmarks { get; set; }
    }
}
